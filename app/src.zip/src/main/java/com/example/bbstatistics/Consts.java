package com.example.bbstatistics;

/**
 * Created by I055150 on 25.3.2015.
 */
public final class Consts {
    public static final String TAG = "BBStat";
}
